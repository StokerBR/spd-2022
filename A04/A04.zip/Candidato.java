public class Candidato {
    public int codigo;
    public String nome;
    public String sexo;
    public String dataNasc;
    public String cargoPretendido;
    public String textoCurriculo;

    public Candidato(int codigo, String nome, String sexo, String dataNasc, String cargoPretendido, String textoCurriculo) {
        this.codigo = codigo;
        this.nome = nome;
        this.sexo = sexo;
        this.dataNasc = dataNasc;
        this.cargoPretendido = cargoPretendido;
        this.textoCurriculo = textoCurriculo;
    }
    
}